package com.marsh.service;

import java.util.List;

import com.marsh.bean.Emp;

public interface EmpService {

	List<Emp> getAll();

}
