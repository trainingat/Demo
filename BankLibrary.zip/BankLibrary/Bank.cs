﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class Bank
    {
        #region Fields & Properties
        private string accHolderName;
        
        public string AccHolderName
        {
            get { return accHolderName; }
            set { accHolderName = value; }
        }

        private double balance;

        public double Balance
        {
            get { return balance; }
          private  set { balance = value; }
        }
        #endregion

        #region Methods
        public void Deposit(double amount)
        {
            Balance += amount;
        }

        public void Withdraw(double amount)
        {
            Balance -= amount;
        }

        public override string ToString()
        {
            return string.Format($"Account Holder Name = {AccHolderName} Balance = {Balance}");
        }
        #endregion

        #region Constructor
        private static int count;

        public static int Count
        {
            get { return count; }
           private set { count = value; }
        }
        public Bank()
        {
            Balance = 1000;
            count++;
        }
       
        public Bank(string name, double amount) : this()
        {

            this.AccHolderName = name;
            this.Balance = amount;
          
        }
        #endregion
    }
}
