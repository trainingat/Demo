package com.marsh;

public class Crane extends Vehicle implements Liftable{

	@Override
	public void lift() {
		System.out.println("Lifting by crane");
		
	}
	
}
