package com.marsh;

public class Bus extends Vehicle  implements Movable{

	@Override
	public void move() {
		System.out.println("Bus is moving");
	}

	@Override
	public String toString() {
		return "Bus " + super.toString() ;
	}
	
}
