package com.marsh.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmpListTest {

	public static void main(String[] args) {
		List<Emp> empList = new ArrayList<>();
		Emp e1 = new Emp(211, "Shaheen", 9012341234L);
		Emp e2 = new Emp(101, "Abhishek", 9099991234L);
		Emp e3 = new Emp(451, "Dipti", 9062991234L);
		Emp e4 = new Emp(191, "Vinit", 9052300234L);
		Emp e5 = new Emp(711, "Arpita", 9012349234L);
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		System.out.println(empList);
		System.out.println("Sort by ID");
		Collections.sort(empList, new EmpComparator(SortField.ID));
		System.out.println(empList);
		System.out.println("Sort by Name");
		//empList.add(e1);
		Collections.sort(empList, new EmpComparator(SortField.NAME));
		System.out.println(empList);
		System.out.println("Sort by Mobile");
		Collections.sort(empList, new EmpComparator(SortField.MOBILE));
		System.out.println(empList);
	}

}
