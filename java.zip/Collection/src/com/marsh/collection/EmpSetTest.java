package com.marsh.collection;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class EmpSetTest {

	public static void main(String[] args) {
		Set<Emp> empSet = new HashSet<>();
		Emp e1 = new Emp(211, "Shaheen", 9012341234L);
		Emp e2 = new Emp(101, "Abhishek", 9099991234L);
		Emp e3 = new Emp(451, "Dipti", 9062991234L);
		Emp e4 = new Emp(191, "Vinit", 9052300234L);
		Emp e5 = new Emp(711, "Arpita", 9012349234L);
		Emp e6 = new Emp(101, "Abhishek", 9099991234L);
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		empSet.add(e6);// duplicate not to be added
		// HashSet has implementation: First check hashcode() if repeated, 
		// then reconfirm if equals() returns true
		System.out.println(empSet);
		TreeSet<Emp> empTree = new TreeSet<>(empSet);
		// TreeSet is sorted by default. So Emp has to implement Comparable interface
		// The compareTo() is called during addition to Tree
		System.out.println(empTree);
		

	}

}
