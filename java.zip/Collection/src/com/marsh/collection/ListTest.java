package com.marsh.collection;

//import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ListTest {
	// List is ordered and indexed
	public static void main(String[] args) {
		List<String> colorList = new CopyOnWriteArrayList<>();
				//new ArrayList<>();
		String[] colorArray = {"red", "blue", "green", "yellow", "orange"};
		// Arrays are fixed in length, cannot modify later
		for (String color : colorArray) {
			colorList.add(color);
		}
		System.out.println(colorList);// toString is implemented in ArrayList
		System.out.println(colorList.get(2)); // returns element at index 2
		colorList.set(2, "brown"); // replaces element at index 2
		System.out.println(colorList);
		colorList.add(3, "green");// inserts at index 3 and pushes other forward
		System.out.println(colorList);
		List<String> removeList = Arrays.asList("green","yellow");// fixed length List
		Iterator<String> iter = colorList.iterator();
		int ctr=0;
		while (iter.hasNext()) {
			ctr++;
			String color = iter.next();
			if(removeList.contains(color)) {
				//iter.remove(); // works with ArrayList only
				colorList.remove(color);
			}
			if(ctr==3) {
				colorList.add("grey");// cannot add. throws ConcurrentModificationException
			}
		}
		System.out.println(colorList);
		// sort
		Collections.sort(colorList );
		System.out.println(colorList);

	}

}
