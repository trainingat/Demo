package com.marsh.paint;

public class PainterMain {

	public static void main(String[] args) {
		Color col = new Red();
		PaintHelper helper = new PaintHelper();
		helper.paintColor(col);
		col = new Green();
		helper.paintColor(col);
		// anonymous class
		col = new Color() {
			@Override
			public void paint() {
				System.out.println("Some color painted");
			}
		};
		helper.paintColor(col);
		// we use JDK 1.8
		//col = ()-> System.out.println("Orange color painted");
		// Lambda expression
		helper.paintColor(()-> System.out.println("Orange color painted"));
		
	}

}
