package com.marsh.inter;

import java.util.Scanner;

import com.marsh.Movable;

public class TestInterfaceMain {

	public static void main(String[] args) {
		// ask the user which type of vehicle they want
		System.out.println("Enter type of vehicle");
		Scanner scan = new Scanner(System.in);
		String type = scan.nextLine();
		Movable m = MovableFactory.getInstance(type);
		if (m != null)
			m.move();
		else
			System.out.println(type + " not found");

	}

}
