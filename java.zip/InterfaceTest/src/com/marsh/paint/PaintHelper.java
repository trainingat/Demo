package com.marsh.paint;

public class PaintHelper {

	public void paintColor(Color col) {		
		col.paint();
	}

}
