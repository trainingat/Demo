package com.marsh.basic;

import com.marsh.Car;


public class MyFirst {

	public static void main(String[] args) {
		
		System.out.println("This is My first Program");
		Car c1 = new Car(); 
		c1.setTyres(5);
		System.out.println("Car tyres: " + c1.getTyres(5));
	}

}
