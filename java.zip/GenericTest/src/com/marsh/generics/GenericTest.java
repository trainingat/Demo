package com.marsh.generics;

public class GenericTest {


	public void execute() {
		Integer[] intArray = {1,2,3,4,5,6};
		printArray(intArray);
		System.out.println();
		Double [] doubleArray = {1.4, 5.5, 9.1, 4.9};
		printArray(doubleArray);
		System.out.println();
		Character[] charArray = {'M', 'A', 'R', 'S', 'H'};
		printArray(charArray);
		System.out.println();
		Integer[] intNums = {1,2,3,4};
		System.out.println(sum(intNums));
		System.out.println(sum(100,20,30));
	}
	
	public int sum(Integer... nums) {
		int mysum = 0;
		for (Integer elem : nums) {
			mysum += elem;
		}
		return mysum;
	}
	
	public<E> void printArray(E[] myArray) {
		for (E elem : myArray) {
			System.out.print(" "  +elem);
		}
	}
//	public void printArray(Integer[] intArray) {
//		for (Integer elem : intArray) {
//			System.out.print(" "  +elem);
//		}
//	}
	public static void main(String... args) {
		new GenericTest().execute();
	}

}
