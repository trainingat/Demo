package com.marsh.sync;
// every object has a monitor which is captured by a thread entering a synchronized block
// no other thread can enter a synchronized block till the earlier thread releases monitor
public class SharedObject implements SharedInterface {
	private int data;
	// wait-notify mechanism to make object thread safe
	synchronized public int getData() {
		notify();
		int temp = data;
		System.out.println("  !!got: "+temp);
		try { wait(1000);} catch (InterruptedException e) {}
		return temp;
	}

	synchronized public void setData(int data) {
		notify();
		System.out.println("set: "+data);
		this.data = data;
		try { wait(1000);} catch (InterruptedException e) {}
	}
	
}
