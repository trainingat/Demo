﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankLibrary;

namespace OPPsTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();
            bank.AccHolderName = "Abhishek";
           // bank.Balance = 2000;

            Console.WriteLine(bank);

            bank.Deposit(3000);
            Console.WriteLine("After deposite --" + bank);

            bank.Withdraw(1000);
            Console.WriteLine("After Withdraw -- " + bank);

            Console.WriteLine("---------------------------");

            Bank bank1 = new Bank("VIshal", 5000);
            Bank bank2 = new Bank("Prachi", 7000);
            Console.WriteLine(bank1);
            Console.WriteLine(bank2);

            //total number of bank account created
            Console.WriteLine(Bank.Count);

            Console.ReadLine();
        }
    }
}
