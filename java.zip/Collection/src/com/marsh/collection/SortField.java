package com.marsh.collection;

public enum SortField {
	ID, NAME, MOBILE;
}
