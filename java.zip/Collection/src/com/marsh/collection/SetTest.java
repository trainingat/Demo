package com.marsh.collection;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetTest {
	// Set does not allow duplicates, is not ordered
	public static void main(String[] args) {
		Set<String> colorSet = new HashSet<>();
		String[] colorArray = {"red", "blue", "green", "yellow", "red", "orange"};
		for (String color : colorArray) {
			System.out.println( colorSet.add(color));
		}
		System.out.println(colorSet);
		// sort
		TreeSet<String> colorTree = new TreeSet<>(colorSet);
		// TreeSet is sorted by default
		System.out.println(colorTree);
		
	}

}
