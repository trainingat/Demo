package com.marsh.util;

public class Messages {

	public static final String UPDATE_FAILED = "Withdraw failed";
	public static final String INSUFFICIENT_BALANCE = "Insufficient balance in account";
	public static final String NO_ACCOUNT_FOUND = "Account not found";
	public static final String FAILED_CREATION = "Failed to create account";

}
