package com.marsh.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/hello")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("in int()");
	}

	public void destroy() {
		System.out.println("in destroy()");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in doGet()");
		String name = request.getParameter("name");
		System.out.println(name);
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<html><head><title>Response from Servlet</title></head>");
		out.print("<body><h2>Hello "+name+" welcome to the site</h2></body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in doPost()");
		doGet(request, response);
	}

}
