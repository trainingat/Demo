﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCDemoApp.Models;

namespace MVCDemoApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [Route("Home/Greet/{name?}")]
        public ActionResult Greet(string name)
        {
            ViewBag.message = "Hi" + name;
            return View();
        }
        [Route("Home/Add/{a?}/{b?}")]
        public ActionResult Add(int a, int b)
        {
            ViewBag.message = "Addition = " + (a + b);
            return View();
        }

        public ActionResult GetEmployee()
        {
            Employee employee = new Employee() { EmpNo = 101, EmpName = "Abhishek", EmpSalary = 35000 };
            ViewBag.emp = employee;
            return View();
        }

        public ActionResult ModelBinderDemo()
        {
            Employee employee = new Employee() { EmpNo = 101, EmpName = "Abhishek", EmpSalary = 35000 };
          
            return View(employee);
        }

        public ActionResult ModelBinderwithCollection()
        {
            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() { EmpNo = 101, EmpName = "Abhishek", EmpSalary = 35000 });
            empList.Add(new Employee() { EmpNo = 101, EmpName = "Prachi", EmpSalary = 30000 });
            empList.Add(new Employee() { EmpNo = 101, EmpName = "Manohar", EmpSalary = 32000 });
            return View(empList);
        }

        public ActionResult EmployeeForm()
        {
            return View(new Employee());
        }

        public ActionResult PostEmployeeData(Employee employee)
        {
            if (ModelState.IsValid)
            {
                return View(employee);
            }
            return View("EmployeeForm", employee);
        }
    }
}