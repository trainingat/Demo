package com.marsh;

public interface Movable {
	 void move();
}
