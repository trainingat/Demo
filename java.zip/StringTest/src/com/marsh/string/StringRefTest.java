package com.marsh.string;

public class StringRefTest {

	public static void main(String[] args) {
		String str = "Hello";
		str = modify(str);
		
		
		System.out.println("After modify str: " + str);
		StringBuilder sb = new StringBuilder("Hello");
		modify(sb);
		System.out.println("sb: " + sb);

	}
	private static String modify(StringBuilder sb) {
		sb.append(" guys");
		return sb.toString();
		
	}
	
	private static String modify(String str) {
	
		str = str.concat(" guys");
		System.out.println("Here str: " + str);
		return str;
	}

}
