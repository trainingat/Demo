package com.marsh.generics;

public class GenericTester {

	public static void main(String[] args) {
		Basket<Integer> basket = new Basket<>();
		basket.setData(120);
		System.out.println("data: " + basket.getData());
	
		Basket<String> basketCity = new Basket<>();
		basketCity.setData("Pune");
		
			System.out.println("data: " + basketCity.getData());

	}

}
