package com.marsh.paint;

public class Green implements Color {

	@Override
	public void paint() {
		System.out.println("Green color painted");
	}

}
