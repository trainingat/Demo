package com.marsh.string;

import java.util.Scanner;

public class RegExTest {

	
	public boolean isValid(String input) {		
		
		return input.matches("\\d{5}");
	}
	public static void main(String[] args) {
		RegExTest ret = new RegExTest();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 5 digit number");
		String input = scan.nextLine();
	
		boolean valid = ret.isValid(input);
		System.out.println("Valid: " + valid);
		
	}

}
