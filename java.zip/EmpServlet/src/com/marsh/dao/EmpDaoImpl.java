package com.marsh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.marsh.bean.Emp;
import com.marsh.util.DBUtil;

public class EmpDaoImpl implements EmpDao {

	@Override
	public List<Emp> getAll() {
		String query = "select id,name,mobile,designation from employee";
		List<Emp> empList = new ArrayList<>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Emp e = 
				new Emp(rs.getInt(1), rs.getString(2), rs.getLong(3), rs.getString(4));
				empList.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return empList;
	}

}
