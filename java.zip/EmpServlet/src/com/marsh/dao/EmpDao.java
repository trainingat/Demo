package com.marsh.dao;

import java.util.List;

import com.marsh.bean.Emp;

public interface EmpDao {

	List<Emp> getAll();

}
