package com.marsh.dao;

import com.marsh.bean.Customer;
import com.marsh.util.BankingException;

public interface BankingDao {

	boolean createCustomer(Customer cust);

	double getBalance(long accNo);

	
	long getAccNo(long accNo1);

	double setBalance(long acc, double amt);

	double withdrawAmount(long accNo, double amount) throws BankingException, BankingException;



}
