package com.marsh.inter;

import com.marsh.Bus;
import com.marsh.Car;
import com.marsh.Movable;
import com.marsh.Van;
// follows design pattern called factory pattern
public class MovableFactory {
   // factory method
	public static Movable getInstance(String type) {
		if("car".equalsIgnoreCase(type)) {
			return new Car();
		} else if("bus".equalsIgnoreCase(type)) {
			return new Bus();
		} else if("van".equalsIgnoreCase(type)) {
			return new Van();
		} 
		//return new DefaultVehicle();
		// local, inner anonymous class
		return new Movable() {			
			@Override
			public void move() {
				System.out.println("Anonymous vehicle moving");
			}
		};
	}
	// inner class :  a class defined inside another class
	private static class DefaultVehicle implements Movable{
		@Override
		public void move() {
			System.out.println("Default vehicle moving");
		}		
	}

}
