package com.marsh;

public class Car extends Vehicle implements Movable{
	
	
	
	@Override
	public void move() {
		System.out.println("Car is moving");
		
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	@Override
	public String toString() {
		return "Car " + super.toString();
	}

	public Car() {
		super();
	}

	public Car(int tyres, String type, double cost) {
		super(tyres, type, cost);
	}

	@Override
	public int getTyres() {
		return super.getTyres();
	}
	
	
	public int getTyres(int tyre) {
		return super.getTyres()+ tyre;
	}
}
