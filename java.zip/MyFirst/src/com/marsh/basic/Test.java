package com.marsh.basic;

public class Test {

	public static void main(String[] args) {
		System.out.println("Inside Main");
		Child child1 = new Child();
		child1.m();
		Child child2 = new Child();
		child2.id = 333;
		System.out.println(child1.id);
		double max = Math.max(34,51);
		System.out.println(max);
		
	}

}
