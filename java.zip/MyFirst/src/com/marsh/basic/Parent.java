package com.marsh.basic;

public class Parent {
	static int id=1234;
	static {
		System.out.println("inside static block parent");
	}
	public final void m() {
		System.out.println("in m() parent");
	}
	public Parent() {
		System.out.println("parent constr");
	}
}
