package com.marsh.sync;

public class SyncTest {

	public static void main(String[] args) {
		SharedInterface so = new SharedObject();
		Runnable prod = new Producer(so);
		new Thread(prod).start();
		try {Thread.sleep(2);} catch (InterruptedException e) {}
		Runnable cons = new Consumer(so);
		new Thread(cons).start();

	}

}
