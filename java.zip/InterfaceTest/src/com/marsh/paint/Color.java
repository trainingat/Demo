package com.marsh.paint;

public interface Color {
	void paint();
}
