package com.marsh.basic;

public class Child extends Parent{
	static int id=1334;
	static {
		System.out.println("inside static block clild");
	}
	public void m1() {
		System.out.println("in m() clind");
	}
	
	public Child() {
		System.out.println("Child constr");
	}
}
