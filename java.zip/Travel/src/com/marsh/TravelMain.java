package com.marsh;

public class TravelMain {

	public static void main(String[] args) {
		Car c1 = new Car(); 
		c1.setTyres(5);
		System.out.println("Car tyres: " + c1.getTyres(5));
		c1.move();
		Bus b1 = new Bus();
		b1.setTyres(7);
		System.out.println("Bus tyres: " + b1.getTyres());
		b1.move();
		System.out.println(b1);
		Van v1 = new Van();
		v1.setTyres(6);
		System.out.println("Van tyres: " + v1.getTyres());
		v1.move();
		
		Crane cr = new Crane();
		cr.lift();
		Movable c3 = new Car(5,"Honda",1000000);
		c3.move();
		System.out.println(c3);
		Car c4 = new Car(5,"Honda",1000000);
		System.out.println(c4);
		System.out.println(c3==c4);
		System.out.println(c3.equals(c4));
	}

}
