package com.marsh.collection;

import java.util.Comparator;

public class EmpComparator implements Comparator<Emp> {
	private SortField sortField;

	public EmpComparator(SortField sortField) {
		this.sortField = sortField;
	}

	@Override
	public int compare(Emp emp1, Emp emp2) {
		// System.out.println("comparing: " + emp1.getId()+" with "+emp2.getId());
		if (sortField == SortField.NAME) {
			return emp1.getName().compareTo(emp2.getName());
		}
		if (sortField == SortField.MOBILE) {
			return (int) (emp1.getMobile() - emp2.getMobile());
		}
		return emp1.getId() - emp2.getId();
	}

}
