package com.marsh.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapTest {

	public static void main(String[] args) {
		Map<String, String> itemMap = new HashMap<>();
		itemMap.put("mobile", "Samsung");
		itemMap.put("tv", "Sony");
		itemMap.put("laptop", "HP");
		itemMap.put("watch", "Titan");
		itemMap.put("bike", "Suzuki");
		itemMap.put("laptop", "Lenovo");
		System.out.println(itemMap);
		System.out.println(itemMap.get("bike"));
		Set<String> keys = itemMap.keySet();
		for (String item : keys) {
			System.out.println(itemMap.get(item));
		}
	}

}
