package com.marsh.collection;

public class Emp implements Comparable<Emp>{
	private int id;
	private String name;
	private long mobile;
	String delim = System.getProperty("line.separator");
	public Emp() {
	}

	@Override
	public int compareTo(Emp e) {
		//System.out.println(id+" compared to : "+e.getId());
		return id-e.getId();
	}
	@Override
	public int hashCode() {
		//System.out.println("id: " + id);
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		//System.out.println("equals: " + obj);
		Emp e = (Emp) obj;
		return name.equals(e.getName()) && mobile==e.getMobile();
	}

	public Emp(int id, String name, long mobile) {
		this.id = id;
		this.name = name;
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return delim+"Emp [id=" + id + ", name=" + name + ", mobile=" + mobile + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}


}
