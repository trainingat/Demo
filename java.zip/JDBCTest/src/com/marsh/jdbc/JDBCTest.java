package com.marsh.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

class JDBCTest {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/marsh", "root", "root");
			System.out.println("Connection Established");
			Statement stmt = conn.createStatement();
//			String query1 = "INSERT INTO employee(name,mobile) " + "VALUES('Demo', 8976543212)";
//			PreparedStatement stmt1 = conn.prepareStatement(query1);
//			stmt1.executeQuery(query1);
			ResultSet rs = stmt.executeQuery("select *from employee");
			while(rs.next()) {
				System.out.println(rs.getInt(1)+ " "+ rs.getString(2)+ " "+rs.getLong(3));
			}
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

};