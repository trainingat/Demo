package com.marsh.thread;

public class MyRunnable implements Runnable {

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("    == in run: "+i);
			try {Thread.sleep(2);} catch (InterruptedException e) {}
		}
		
	}

	public static void main(String[] args) {
		Thread t = new Thread(new MyRunnable());
		t.start();
		for (int i = 1; i <= 10; i++) {
			System.out.println("in main: "+i);
			try {Thread.sleep(2);} catch (InterruptedException e) {}
		}

	}

}
