package com.marsh.string;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IDValidator {
	
	private Pattern pattern;
	private Matcher matcher;
	String regex = "^(\\d{3}-?\\d{2}-?\\d{4})$";

	private boolean isValid(String input) {
		matcher = pattern.matcher(input);
		return matcher.matches();
	}
	
	public IDValidator() {
		pattern = Pattern.compile(regex);
	}
	
	public static void main(String[] args) {
		IDValidator ret = new IDValidator();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter ID <nnn-nn-nnnn>");
		String input = scan.nextLine();
		boolean valid = ret.isValid(input);
		System.out.println("Valid: " + valid);
		
	}

	

}
