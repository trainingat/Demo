package com.marsh.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.marsh.bean.Emp;
import com.marsh.service.EmpService;
import com.marsh.service.EmpServiceImpl;

@WebServlet(urlPatterns= {"/viewall"})
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmpService eService;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in doGet()");
		List<Emp> empList = eService.getAll();
		System.out.println(empList);
		if(empList.size()>0) {
			HttpSession session = request.getSession();
			session.setAttribute("list", empList);
			request.getRequestDispatcher("list.jsp").forward(request, response);
		}
		else {
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	public void init(ServletConfig config) throws ServletException {
		eService = new EmpServiceImpl();
	}

	public void destroy() {
	}

}
