package com.marsh.service;

import java.util.List;

import com.marsh.bean.Emp;
import com.marsh.dao.EmpDao;
import com.marsh.dao.EmpDaoImpl;

public class EmpServiceImpl implements EmpService {
	private EmpDao eDao;
	
	public EmpServiceImpl() {
		eDao = new EmpDaoImpl();
	}

	@Override
	public List<Emp> getAll() {
		return eDao.getAll();
	}

}
