package com.marsh.paint;

public class Red implements Color {
	@Override
	public void paint() {
		System.out.println("Red color painted");
	}
}
