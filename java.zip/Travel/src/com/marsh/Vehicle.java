package com.marsh;


public abstract class Vehicle {
	private int tyres;
	private String type;
	private double cost;

	@Override
	public boolean equals(Object obj) {
		Vehicle v = (Vehicle) obj;
	    return tyres==v.getTyres() && type.equals(v.getType()) && cost==v.getCost();
		
	}
	@Override
	public String toString() {
		return " [tyres=" + tyres + ", type=" + type + ", cost=" + cost + "]";
	}
	
	public Vehicle() {
		super(); 
	}
	
	public Vehicle(int tyres, String type, double cost) {
		super();
		this.tyres = tyres;
		this.type = type;
		this.cost = cost;
	}

	public int getTyres() {
		return tyres;
	}

	public void setTyres(int tyres) {
		this.tyres = tyres;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

}
