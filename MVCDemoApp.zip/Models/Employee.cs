﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVCDemoApp.Models
{
    public class Employee
    {
        [Required(ErrorMessage ="EmpNo is Required")]
        public int? EmpNo { get; set; }

        [Required(ErrorMessage = "EmpName is Required")]
        public string EmpName { get; set; }

        [Required(ErrorMessage = "EmpSalary is Required")]
        public double? EmpSalary { get; set; }
    }
}