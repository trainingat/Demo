package com.marsh;

public interface Liftable {
	public void lift();
	
}
 