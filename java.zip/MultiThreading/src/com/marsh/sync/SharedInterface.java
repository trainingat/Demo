package com.marsh.sync;

public interface SharedInterface {
	public void setData(int data);
	public int getData();
}
